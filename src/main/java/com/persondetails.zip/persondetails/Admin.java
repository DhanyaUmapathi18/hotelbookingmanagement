package com.persondetails;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

import com.helpers.Database;

public class Admin {

	/**
	 * Adds Room
	 * Update Room
	 * Delete Room
	 * Billing
	 */

	Scanner scanner = new Scanner(System.in);
	public Admin() throws ClassNotFoundException  {
		getUserInput();
	}
	private void getUserInput() throws ClassNotFoundException{
		if(login()){
			adminOperations();
		}
		
	}
	public boolean login() throws ClassNotFoundException {
		System.out.println("Login");
		System.out.print("UserName : ");
		String name = scanner.next();
		System.out.print("Password : ");
		String adminpassword = scanner.next();
		if(isValidate(name,adminpassword)){
			System.out.println("Logined successfull");
			return true;
	}
		else{
			System.out.println("Invalid username or password!");
			return false;
		}
	}
	static boolean isValidate(String name, String adminPassword) throws ClassNotFoundException {
			final String QUERY_SELECT = "SELECT * FROM HotelManagement.ADMIN WHERE USERNAME = ? AND PASSWORD = ?";
			 try (Connection connection = Database.getConnection();
		             PreparedStatement preparedStatement = connection.prepareStatement(QUERY_SELECT)) {
		            preparedStatement.setString(1, name);
		            preparedStatement.setString(2, adminPassword);
		            try (ResultSet resultSet = preparedStatement.executeQuery()) {
		                return resultSet.next();
		            }

		        } catch (SQLException e) {
		        	System.out.println(e.getMessage());
		            return false;
		        }
		}

		public void adminOperations(){
			short choice;
			do{
				System.out.println("-----------------------------------------------------------------------------");
				System.out.println("1. Add Room");
				System.out.println("2. Update Room");
				System.out.println("3. Delete Room");
				System.out.println("4. Book Room");
				System.out.println("5. Cancel Room");
				System.out.println("6. Billing");
				System.out.println("7. Go back to main menu");
				System.out.println("8. Exit");
				System.out.println("-----------------------------------------------------------------------------");
				System.out.print("Enter your choice : ");
				choice  = scanner.nextShort();
				switch(choice){
					case 1 : AdminOperations.addRoom();
							 break;
				    case 2 : //updateRoom();
							 break;
					case 3 : //deleteRoom();
							 break;
					case 4 : //bookRoom();
							 break;
					case 5 : //cancelRooom();
							 break;
					case 6 : //billing();
							 break;
					case 7 : adminOperations();
							break;
					case 8 : System.exit(0);
							break;
				}
				choice = scanner.nextShort();
			} while(choice>0 && choice<9);
		}
		
}
