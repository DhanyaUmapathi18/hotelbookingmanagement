package com.persondetails;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import com.roomdetails.Room;

import com.helpers.Database;
import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.SQLException;

public class AdminOperations {
	List<Room> rooms = new ArrayList<>();
	static Scanner scanner = new Scanner(System.in);
	public static  void addRoom(){
		System.out.println("Enter RoomNumber");
		int roomNumber = scanner.nextInt();
		System.out.println("Enter RoomType");
		String roomType = scanner.nextLine();
		System.out.println("Enter Price : ");
		float price = scanner.nextFloat();
		String Availability = scanner.nextLine();
		System.out.println(		);

		try(Connection conn = Database.getConnection();
			PreparedStatement statement = conn.prepareStatement("")){

		} catch (ClassNotFoundException | SQLException e) {
			System.out.print("Error : "+ e.toString());
		}
	}
}
