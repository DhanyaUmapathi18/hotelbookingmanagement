package com.persondetails;

import java.util.Scanner;

public class DriverHotelManagement {

	public static void main(String[] args) throws ClassNotFoundException {
		Scanner scanner = new Scanner(System.in);
		System.out.println("WELCOME TO HOTEL BOOKING MANAGEMENT");
		System.out.println("Welcome!!! Are you \n1.Admin \n2.Customer \n3.Receptionist");
    	short choice = scanner.nextShort();
   		do{
			switch(choice)
   			{
   				case 1:Admin admin = new Admin();
    				   break;
				case 2:Customer customer = new Customer();
    				   break;					
    			case 3://Guest account = new Guest();
    				   break;
				case 4: System.exit(0);
						break;
    	    	default : System.out.println("Please enter valid number");
   			}
			choice = scanner.nextShort();
    	}while(choice>0 && choice<5);
    	}
	}