package com.persondetails;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.helpers.Database;

public class Customer extends Person {

	static int PersonID = 100;
	Account account = new Account();
	static Scanner scanner = new Scanner(System.in);

	public Customer() throws ClassNotFoundException {
		getUserInput();
	}

	private void getUserInput() throws ClassNotFoundException {
		System.out.println("1.Register\n2.Login");
		int choice = scanner.nextInt();
		switch (choice) {
			case 1:
				register();
				break;
			case 2:
				if (account.login())
					roomBookingProcess();
				break;
		}
	}

	public void register() throws ClassNotFoundException {
		String dob;
		System.out.println("Register:");
		// System.out.print("Enter PersonID: ");
		// setPersonId(scanner.next());
		System.out.print("Enter First name: ");
		setFirstName(scanner.next());
		System.out.print("Enter Last name: ");
		setLastName(scanner.next());
		System.out.print("Enter Gender (M/F): ");
		setGender(scanner.next().charAt(0));
		String email;
		do {
			System.out.print("Enter email: ");
			email = scanner.next();
			if (!isValidEmail(email)) {
				System.out.println("Invalid email format. Please enter a valid email.");
			}
		} while (!isValidEmail(email));

		setEmail(email);
		System.out.print("Enter Phone Number: ");
		setPhoneNumber(scanner.nextLong());
		System.out.print("Enter Address: ");
		scanner.nextLine();
		setAddress(scanner.nextLine());
		System.out.print("Enter DateOfBirth (dd-MM-yyyy): ");
		dob = scanner.nextLine();
		setDateOfBirth(dob);
		System.out.print("Enter Username: ");
		setUserName(scanner.next());
		System.out.println(
				"Passwod should contain 1 upperr case,lower case,1 digits and special symbol.It must be length of 8");
		System.out.print("Enter Password: ");
		setPassword(scanner.next());

		if (saveToDatabase()) {
			System.out.println("Registration successful!");
		} else {
			System.out.println("Registration failed. Please try again.");
		}
	}

	boolean isValidEmail(String email) {
		String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$";
		Pattern pattern = Pattern.compile(emailRegex);
		Matcher matcher = pattern.matcher(email);
		return matcher.matches();
	}

	boolean saveToDatabase() throws ClassNotFoundException {
		String QUERY_INSERT = "INSERT INTO HotelManagement.CUSTOMER VALUES(?,?,?,?,?,?,?,?,?,?)";

		try (Connection connection = Database.getConnection();
				PreparedStatement statement = connection.prepareStatement(QUERY_INSERT);) {
			String PERSONID = "SELECT MAX(PersonID) FROM HotelManagement.CUSTOMER";
			try (PreparedStatement maxIdStatement = connection.prepareStatement(PERSONID);
					ResultSet resultSet = maxIdStatement.executeQuery()) {
				if (resultSet.next()) {
					PersonID = resultSet.getInt(1) + 1;
					setPersonId(String.valueOf(PersonID));
				}
			}

			statement.setString(1, getPersonId());
			statement.setString(2, getFirstName());
			statement.setString(3, getLastName());
			statement.setString(4, String.valueOf(getGender()));
			statement.setString(5, getEmail());
			statement.setString(6, getDateOfBirth());
			statement.setLong(7, getPhoneNumber());
			statement.setString(8, getAddress());
			statement.setString(9, getUserName());
			statement.setString(10, getPassword());
			int rowsAffected = statement.executeUpdate();
			return rowsAffected > 0;
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}

	public void roomBookingProcess() {
		short choice;
		System.out.println("-------------------------------------------------------------------------------------");
		System.out.println("Room Booking Menu");
		System.out.println("1. Check Availability ");
		System.out.println("2. Book Room");
		System.out.println("3. Cancel Booking");
		System.out.println("4. Check In");
		System.out.println("5. Check Out");
		System.out.println("6. Calculate Total Cost");
		System.out.println("7. Go Back To Main Menu");
		System.out.println("8. Exit");
		System.out.println("-------------------------------------------------------------------------------------");
		choice = scanner.nextShort();
		do {
			switch (choice) {
				case 1: // checkAvaliability();
					break;
				case 2: // roomBooking();
					break;
				case 3: // cancelBooking();
					break;
				case 4: // checkIn();
					break;
				case 5: // checkOut();
					break;
				case 6: // calculateTotalCost();
					break;
				case 7: // roomBookingProcess();
					break;
				case 8:
					System.exit(0);
			}
			choice = scanner.nextShort();
		} while (choice > 0 && choice < 9);
	}
}