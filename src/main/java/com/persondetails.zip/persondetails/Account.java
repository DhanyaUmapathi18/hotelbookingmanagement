package com.persondetails;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

class Account  {
	static Scanner scanner = new Scanner(System.in);
	final  String URL = "jdbc:oracle:thin:@localhost:1521:xe";
	final  String userName = "HotelManagement";
	final  String password = "HotelManagement";
	private  String loginName;
	private  String loginPassword;
	public  boolean login() throws ClassNotFoundException {
		System.out.println("Login");
		System.out.print("UserName : ");
		loginName = scanner.next();
		System.out.print("Password : ");
		loginPassword = scanner.next();
		if(isValidate(loginName,loginPassword)){
			System.out.println("Logined successfull");
			return true;
		}
		else{
			System.out.println("Invalid username or password!");
			return false;
		}
	}

	 boolean isValidate(String name, String customerPassword) throws ClassNotFoundException {
	    Class.forName("oracle.jdbc.driver.OracleDriver");
	    final String QUERY_SELECT = "SELECT * FROM HotelManagement.CUSTOMER WHERE USER_NAME = ? AND PASSWORD = ?";
	    try (Connection connection = DriverManager.getConnection(URL, userName, password);
	         PreparedStatement preparedStatement = connection.prepareStatement(QUERY_SELECT)) {
	        preparedStatement.setString(1, name);
	        preparedStatement.setString(2, customerPassword);
	        try (ResultSet resultSet = preparedStatement.executeQuery()) {
	            if (resultSet.next()) 
	                return true;
	             else 
	                return false;
	            
	        }
	    } catch (SQLException e) {
	        System.out.println(e.getMessage());
	        return false;
	    }
	}
}
